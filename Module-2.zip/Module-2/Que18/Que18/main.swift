//
//  main.swift
//  Que18
//
//  Created by Krushal's Macbook on 28/02/23.
//

import Foundation

print("Hello, World!")

