//
//  main.swift
//  que13
//
//  Created by mac on 02/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var str = ["tejas", "krushal","saket"]
print(str)
