//
//  main.swift
//  que5
//
//  Created by mac on 28/02/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation



let a = 12
let b = 6

let sum = a+b
print("sum:\(sum)")

let mul = a*b
print("mum:\(mul)")

let div = a/b
print("div:\(div)")

let dif = a-b
print("dif:\(dif)")




