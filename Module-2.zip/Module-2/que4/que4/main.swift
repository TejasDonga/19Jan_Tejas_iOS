//
//  main.swift
//  que4
//
//  Created by mac on 24/02/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation
print("enter a :")
var a = Int(readLine()!)!
print("enter b:")
var b = Int(readLine()!)!
print("enter c:")
var c = Int(readLine()!)!
print("enter c:")

if (a<b){
    if (b<c){
    print("c is max:")
}else if (c<b){
    print("b is max:")
}else if(b<a){
    print("a is max:")
    }else{
        print("a is max:")
    }
}


