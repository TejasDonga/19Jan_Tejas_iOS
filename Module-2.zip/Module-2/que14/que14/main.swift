//
//  main.swift
//  que14
//
//  Created by mac on 02/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var product = ("mobile", 19999)
print("enter a value:")

print("name:",product.0)
print("perice:",product.1)
