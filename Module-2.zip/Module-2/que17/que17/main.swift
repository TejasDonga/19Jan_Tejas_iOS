//
//  main.swift
//  que17
//
//  Created by mac on 02/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation


 var num = [1,2,3,5]
num.append(4)
var index = 3

print(num)


 
