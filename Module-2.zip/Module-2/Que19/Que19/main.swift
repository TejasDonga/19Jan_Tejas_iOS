//
//  main.swift
//  Que19
//
//  Created by Krushal's Macbook on 28/02/23.
//

import Foundation

var data = ["1","2","3","4","5"]
print("Enter a element: ")

var value = readLine()!
var result = data.contains(value)


    if result  {
        print("Value is available: [\(value)]")
    }
    else {
        print("[]")
    }

