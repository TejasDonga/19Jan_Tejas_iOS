//
//  main.swift
//  Que1
//
//  Created by mac on 24/02/23.
//  Copyright © 2023 mac. All rights reserved.
//







import Foundation

print("enter a value :")

var str = readLine()!
print("name is:\(str)")


