//
//  main.swift
//  que9
//
//  Created by mac on 28/02/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var value : Int? = nil
let a = value ?? 0
print(a)


