//
//  main.swift
//  que15
//
//  Created by mac on 02/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var set1: Set = [1, 2, 3]
print("set1:", set1)
var set2: Set = [2, 3, 4]
print("set2:", set2)

print("Intersection:", set1.intersection(set2))



