//
//  main.swift
//  que2
//
//  Created by mac on 24/02/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

print("enter a number :")
var num = Int(readLine()!)!
print("my number :\(num)")
