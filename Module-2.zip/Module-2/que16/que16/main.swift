//
//  main.swift
//  que16
//
//  Created by mac on 02/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation



var data = ["id": "1","name": "tejas","city": "surat"]
print("data", (data))
