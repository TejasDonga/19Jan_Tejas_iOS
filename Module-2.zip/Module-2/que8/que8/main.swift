//
//  main.swift
//  que8
//
//  Created by mac on 28/02/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var a = 23
var b = 12
var c = 3
c = a+b
print("sum:",c)

c = a*b
print("mul:",c)

c = a/b
print("div:",c)

c = a-b
print("dif:",c)

