//
//  main.swift
//  Que21
//
//  Created by Krushal's Macbook on 01/03/23.
//

import Foundation

var symbol = "\u{20B9}"
print("Ruppee symbol = \(symbol)")
