//
//  main.swift
//  que6
//
//  Created by mac on 28/02/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation


let a = 10
let b = Float(a)
print(b)



