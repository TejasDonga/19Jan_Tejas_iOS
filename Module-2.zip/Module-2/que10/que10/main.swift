//
//  main.swift
//  que10
//
//  Created by mac on 28/02/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var a = 23
var b = 12
var c = 20
var d = 10



