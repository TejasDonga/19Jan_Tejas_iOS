//
//  main.swift
//  que12
//
//  Created by mac on 02/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation



