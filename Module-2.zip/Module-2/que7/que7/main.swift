//
//  main.swift
//  que7
//
//  Created by mac on 28/02/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

let name = "tejas"
let age = 19
print("my name is: \(name)")
print("my age is:\(age)")

