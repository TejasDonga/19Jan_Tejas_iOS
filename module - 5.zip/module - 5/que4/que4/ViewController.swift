//
//  ViewController.swift
//  que4
//
//  Created by MacBookPro on 09/05/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var tbl_VIew: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tbl_VIew.delegate=self
        self.tbl_VIew.dataSource=self
    }


}

extension ViewController: UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myimg = tableView.dequeueReusableCell(withIdentifier: "TVC")as! TVC
        return myimg
    }
    
    
}
