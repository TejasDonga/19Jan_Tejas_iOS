//
//  TVC.swift
//  que4
//
//  Created by MacBookPro on 09/05/23.
//

import UIKit

class TVC: UITableViewCell {
    
    @IBOutlet weak var myimg: UIImageView!
    @IBOutlet weak var lbl_data: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
