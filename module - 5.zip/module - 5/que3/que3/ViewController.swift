//
//  ViewController.swift
//  que3
//
//  Created by MacBookPro on 09/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tbl_View: UITableView!
    var city = [["Ahmedabad","Vadodara","Surat","Jamnagar","Rajkot"],["Junagadh ","Bhavnagar","Porbandar","Patan"],["Anand","Bharuch","Mehsana","Valsad"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tbl_View.dataSource=self
        self.tbl_View.delegate=self
    }


}
extension ViewController: UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return city[section].count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVC")as! TVC
        cell.lbl_data.text=city[indexPath.section][indexPath.row]
        if indexPath.section == 0{
            cell.accessoryType = .checkmark
        }
        if indexPath.section == 1{
            cell.accessoryType = .detailButton
        }
        else if indexPath.section == 2{
            cell.accessoryType
            = .detailDisclosureButton
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 20))
        return view
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let view = UIView(frame:CGRect(x: 0, y: 0, width: tableView.frame.width, height: 20))
        return view
    }
}
