//
//  ViewController.swift
//  que7
//
//  Created by MacBookPro on 12/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    
    var data = [""]
    override func viewDidLoad() {
        super.viewDidLoad()
         
        self.tblView.dataSource=self
        self.tblView.delegate=self
        
        data=["tejas","krushal","aman","jatin","parth","radhay","meet","dhruves"]
    }


}
extension ViewController : UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVC")as! TVC
        cell.lbl_data.text=data[indexPath.row]
        cell.btn_detail.setTitle("detail", for: .normal)
//        cell.btn_detail.addTarget(self, action: #selector(btn_detailTapped(_:)), for: .touchUpInside)
        
            return cell
    }
    
    
}
