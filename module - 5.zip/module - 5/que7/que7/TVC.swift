//
//  TVC.swift
//  que7
//
//  Created by MacBookPro on 12/05/23.
//

import UIKit

class TVC: UITableViewCell {
    @IBOutlet weak var lbl_data: UILabel!
    
    @IBOutlet weak var btn_detail: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
