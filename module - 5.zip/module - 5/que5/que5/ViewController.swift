//
//  ViewController.swift
//  que5
//
//  Created by MacBookPro on 09/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tbl_View: UITableView!
    
    var name = [""]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tbl_View.delegate=self
        self.tbl_View.dataSource=self
        
        name = ["Mumbai","Hyderabad","Surat","Pune","Jaipur","Visakhapatnam","Kanpur","Bhopal","Vadodara"]
    }
  
   
        
    }



extension ViewController: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return name.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVC")as! TVC
        cell.lbl_data.text=name[indexPath.row]
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if( editingStyle == .delete) {
            
            
        }
    }
   
        
    }

