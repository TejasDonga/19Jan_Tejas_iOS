//
//  ViewController.swift
//  que2
//
//  Created by MacBookPro on 09/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tbl_view: UITableView!
    
    var name = [["Mahindra","TOYOTA","Audi","Volkswagen","Ford"],["Mercedes Benz ","Kia","Hyundai","Volvo"],["Porsche","Land Rove","Bentley","Lexus"]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tbl_view.delegate = self
        self.tbl_view
            .dataSource = self
       
        
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return name[section].count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVC") as! TVC
        //        if indexPath.section == 0{
        //            cell.contentView.backgroundColor = UIColor.gray
        //
        //        }
        //        if indexPath.section == 1{
        //            cell.contentView.backgroundColor = UIColor.gray
        //        }
        //        if indexPath.section == 2{
        //            cell.contentView.backgroundColor = UIColor.gray
        //        }
        cell.lbl_data.text = name[indexPath.section][indexPath.row]
        
        return cell
    }
    
    //    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    //        if indexPath.section == 0{
    //            return 44
    //        }else if indexPath.section == 1{
    //            return 44
    //        }else{
    //            return 44
    //        }
    ////        return 44
    //    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 20
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 20
            }
            func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
                let view = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 20))
                view.backgroundColor = UIColor.lightGray
                return view
            }
            func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
                let view = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 20))
                view.backgroundColor = UIColor.lightGray
                return view
        
            }
        
        }

