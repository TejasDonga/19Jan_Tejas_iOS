//
//  ViewController.swift
//  que9
//
//  Created by MacBookPro on 05/06/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

