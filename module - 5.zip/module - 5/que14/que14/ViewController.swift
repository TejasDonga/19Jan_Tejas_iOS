//
//  ViewController.swift
//  que14
//
//  Created by MacBookPro on 06/06/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

