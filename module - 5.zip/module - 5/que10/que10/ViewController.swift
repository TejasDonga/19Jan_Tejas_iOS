//
//  ViewController.swift
//  que10
//
//  Created by MacBookPro on 05/06/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nvg_first: UINavigationBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func btn_red(_ sender: Any)
    {
//        let vc = navigationController?.storyboard?.instantiateViewController(withIdentifier: "secondViewController")as! secondViewController
        tabBarController?.tabBar.barTintColor = UIColor.green
        
//        navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func btn_green(_ sender: Any)
    {
        let vc = navigationController?.storyboard?.instantiateViewController(withIdentifier: "thirdViewController") as! thirdViewController
        navigationController?.pushViewController(vc, animated: true)
    }
}

