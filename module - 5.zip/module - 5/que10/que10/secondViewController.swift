//
//  secondViewController.swift
//  que10
//
//  Created by MacBookPro on 05/06/23.
//

import UIKit

class secondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

}
