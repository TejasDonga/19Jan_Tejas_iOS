//
//  ViewController.swift
//  que16
//
//  Created by MacBookPro on 06/06/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txt_password: UITextField!
    
    @IBOutlet weak var txt_user: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_login(_ sender: Any)
    {
        let alert = UIAlertController(title: "Success", message: "Data Successfully Saved !!!", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default)
        alert.addAction(ok)
        present(alert,animated: true)
    }
    
}


