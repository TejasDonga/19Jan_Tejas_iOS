//
//  ViewController.swift
//  que6
//
//  Created by MacBookPro on 12/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tbl_View: UITableView!
    
    var data = [""]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tbl_View.delegate=self
        self.tbl_View.dataSource=self
        
        data = ["ahamdabad","junagadh","rajkot","surat","baroda","amreli","vadodara"]
    }


}

extension ViewController: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVC")as! TVC
        cell.lbl_data.text=data[indexPath.row]
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
}
