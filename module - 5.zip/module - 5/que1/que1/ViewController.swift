//
//  ViewController.swift
//  que1
//
//  Created by MacBookPro on 08/05/23.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var city = [""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tblView.delegate=self
        self.tblView.dataSource=self
        
        city=["junagadh","amdavad","rajkot","surat","baroda","jamnagar","bhavnagar",]
        
    }


}
extension ViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return city.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let call = tableView.dequeueReusableCell(withIdentifier: "TVC")as! TVC
        call.lbl_data.text=city[indexPath.row]
        return call
    }
}
