//
//  ViewController.swift
//  que11
//
//  Created by mac on 27/04/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var pickerview: UIPickerView!
    var pickerdata = [""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.pickerview.delegate=self
        self.pickerview.dataSource=self
        
        pickerdata=["ios","php","java","html","dbms"]
        
    }


}
extension ViewController:UIPickerViewDelegate,UIPickerViewDataSource{
func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 1
}

func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    return pickerdata.count
    
    
}
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerdata[row]
    }

}
