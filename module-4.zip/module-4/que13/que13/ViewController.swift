//
//  ViewController.swift
//  que13
//
//  Created by mac on 05/05/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var pickerview: UIPickerView!
    var pickerdata = [""]
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.red
        self.pickerview.delegate=self
        self.pickerview.dataSource=self
        pickerdata=["Red","Green","Orange","white"]
    }


}
extension ViewController:UIPickerViewDataSource,UIPickerViewDelegate
{
func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 1
}

func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    return pickerdata.count
    
}
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerdata[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {

        if row == 0{
            view.backgroundColor=UIColor.red
        }
        else if row == 1{
            view.backgroundColor=UIColor.green
        }
        else if row == 2{
            view.backgroundColor=UIColor.orange
        }
        else {view.backgroundColor=UIColor.white}
    }
}
