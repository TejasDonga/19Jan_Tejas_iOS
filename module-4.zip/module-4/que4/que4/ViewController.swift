//
//  ViewController.swift
//  que4
//
//  Created by mac on 25/04/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var lbl_show: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl_show.isHidden=true
    }
    @IBAction func btn_hide(_ sender: Any)
    {
        lbl_show.isHidden=true
    }
    @IBAction func btn_show(_ sender: Any)
    {
        lbl_show.isHidden=false
    }
    

}

