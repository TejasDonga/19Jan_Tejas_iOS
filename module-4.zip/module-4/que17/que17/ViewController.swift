//
//  ViewController.swift
//  que17
//
//  Created by mac on 05/05/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nvg_first: UINavigationBar!
    
    @IBOutlet weak var txt_data: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btn_fastforward(_ sender: Any)
    {
       let vc = self.storyboard?.instantiateViewController(withIdentifier: "secondViewController") as!secondViewController
        vc.dr=txt_data.text ?? ""
       navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func btn_cancel(_ sender: Any)
    {
        let alert = UIAlertController(title: "done", message: "", preferredStyle: .actionSheet)
        let OK = UIAlertAction(title: "OK", style: .default, handler: nil)
        let MORE = UIAlertAction(title: "MORE", style: .destructive, handler: nil)
        alert.addAction(OK)
        alert.addAction(MORE)
        present(alert,animated: true)
    }
    
}

