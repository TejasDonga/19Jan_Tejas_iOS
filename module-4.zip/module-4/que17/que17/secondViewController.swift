//
//  secondViewController.swift
//  que17
//
//  Created by mac on 05/05/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class secondViewController: UIViewController {
var dr = ""
    @IBOutlet weak var lbl_data: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl_data.text=dr
    }
   
}
