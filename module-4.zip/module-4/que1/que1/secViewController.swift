//
//  secViewController.swift
//  que1
//
//  Created by mac on 25/04/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class secViewController: UIViewController {
    @IBOutlet weak var lbl_sign: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

   

}
