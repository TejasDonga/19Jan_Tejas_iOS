//
//  ViewController.swift
//  que1
//
//  Created by mac on 25/04/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txt_password: UITextField!
    @IBOutlet weak var txt_username: UITextField!
    @IBOutlet weak var lbl_login: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func btn_login(_ sender: Any) {
    }
    
}

