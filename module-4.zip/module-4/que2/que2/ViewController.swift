//
//  ViewController.swift
//  que2
//
//  Created by mac on 25/04/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var lbl_login: UILabel!
    @IBOutlet weak var txt_username: UITextField!
    @IBOutlet weak var txt_password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }


    @IBAction func btn_login(_ sender: Any)
    {
        let alert = UIAlertController(title: "Success", message: "login Successfully", preferredStyle: .alert)
        let OK = UIAlertAction(title: "OK", style: .default, handler: nil)
        let MORE = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
        alert.addAction(OK)
        alert.addAction(MORE)
        present(alert,animated: true)
    }
}

