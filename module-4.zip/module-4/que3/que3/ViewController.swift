//
//  ViewController.swift
//  que3
//
//  Created by mac on 25/04/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var lbl_password: UILabel!
    @IBOutlet weak var lbl_username: UILabel!
    @IBOutlet weak var txt_password: UITextField!
    @IBOutlet weak var txt_username: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    @IBAction func btn_login(_ sender: UIButton)
    {
        lbl_username.text=txt_username.text
        lbl_password.text=txt_password.text
    }
    
}

