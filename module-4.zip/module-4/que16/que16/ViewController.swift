//
//  ViewController.swift
//  que16
//
//  Created by mac on 05/05/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txt_data: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func btn_shere(_ sender: Any)
    {
        let text = txt_data.text
        let vc = UIActivityViewController(activityItems: [text ?? ""], applicationActivities: nil)
        present(vc, animated: true, completion: nil)
    }
    
}

