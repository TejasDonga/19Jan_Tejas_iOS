//
//  ViewController.swift
//  que5
//
//  Created by mac on 25/04/23.
//  Copyright © 2023 mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btn_ok(_ sender: Any)
    {
        let alert = UIAlertController(title: "Success", message: "SignUp Successfully", preferredStyle: .alert)
        let OK = UIAlertAction(title: "OK", style: .default, handler: nil )
        let MORE = UIAlertAction(title: "MORE", style: .destructive, handler: nil)
        alert.addAction(OK)
        alert.addAction(MORE)
        alert.addTextField(configurationHandler: nil)
        alert.addTextField(configurationHandler: nil)
        present(alert,animated: true)
    }
    
}

