//
//  main.swift
//  que4
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation



func data(r:inout Int,t:inout Int) {
    let c = r
    r = t
    t = c
}
var r = 12
var t = 23
data(r: &r, t: &t)
print("R=\(r), T=\(t)")

