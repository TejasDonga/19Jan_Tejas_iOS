//
//  main.swift
//  que9
//
//  Created by mac on 13/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

class student: NSObject {
    
    func data (id:Int){
        print("enter a id : ",id)
    }
}
class scestudent: student {
    func gatdata (id:Int, name:String)
    {
        print("enter a scestudent id : ",id )
        print("enter a scestudent name: ",name)
        
    }
    override func data (id:Int){
        print("enter a thstudent id : ",id)
    }
}
var st = student()
st.data(id: 1)

var sst = scestudent()
sst.data(id: 2)
sst.gatdata(id: 3, name: "krushal")
sst.data(id: 4)
