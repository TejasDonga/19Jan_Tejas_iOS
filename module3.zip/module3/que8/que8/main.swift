//
//  main.swift
//  que8
//
//  Created by mac on 13/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var nm = manager()
nm.data()
nm.gatdata()
