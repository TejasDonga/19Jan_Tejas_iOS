//
//  employe.swift
//  que8
//
//  Created by mac on 13/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Cocoa

class employe: NSObject {
    var emid = 0
    var emnm = ""
    var emsal = 0
    
    func data()
    {
        print("enter a employe id :")
        emid = Int(readLine()!)!
        print("enter a employe name :")
        emnm = readLine()!
        print("enter a  employe salary :")
        emsal = Int(readLine()!)!
    }
}
