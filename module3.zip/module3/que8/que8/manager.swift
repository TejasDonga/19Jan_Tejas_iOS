//
//  manager.swift
//  que8
//
//  Created by mac on 13/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Cocoa

class manager: employe {
    
    func gatdata()
    {
        print("enter a employe id :",emid )
        print("enter a employe name :",emnm )
        print("enter a employe salary : ",emsal )
    }
}
