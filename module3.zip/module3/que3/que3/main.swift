//
//  main.swift
//  que3
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var data = ["a","b","c","d"]
print("Enter your element (a-z) : ")
let i = readLine()!
print(i)
