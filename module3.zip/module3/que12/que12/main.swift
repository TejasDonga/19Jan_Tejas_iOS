//
//  main.swift
//  que12
//
//  Created by mac on 16/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

@objc protocol data {
    @objc optional func gatdata (id: Int, name: String)
    func gatcontact (mobile:Int)
}
class datail: data {
    func gatcontact(mobile: Int) {
        print("number is : ",mobile)
    }
    
    func gatdata(id: Int, name: String) {
        print("id is :",id)
        print("name is :",name)
    }
}

var tr = datail()
tr.gatdata(id: 1, name: "tejas")

var rt = datail()
rt.gatcontact(mobile: 8980316382)
