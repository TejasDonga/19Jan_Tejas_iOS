//
//  main.swift
//  que13
//
//  Created by mac on 16/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

print("Hello, World!")

