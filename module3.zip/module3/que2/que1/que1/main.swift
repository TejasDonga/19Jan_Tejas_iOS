//
//  main.swift
//  que1
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var  trr = [ "surat", "rajkot", "baroda"]
if let A = trr.firstIndex(of: "surat"){
    trr[A] = "junaghadh"
}
print(trr)
