//
//  main.swift
//  que2
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

var data = ["id":"1", "name":"tejas", "city":"junaghadh"]

print(data["name"]!)

