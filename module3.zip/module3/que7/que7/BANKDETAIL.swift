//
//  BANKDETAIL.swift
//  que7
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Cocoa

class BANKDETAIL: BANK_PARSAL {

    func gatdata(){
        print("account holdar name:",acnm)
        print(" holder account number:  ",acno)
        print("account holadr mobile number: :",acmo)
        print("account holder email:", acmail)
        
    }
    

}
