//
//  BANKPARSAL.swift
//  que7
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation


class BANK_PARSAL: NSObject {
    var acnm = String()
    var acno = Int()
    var acmo = Int()
    var acmail = String()
    
    func data()
    {
        print("enter account holder name :")
        acnm = readLine()!
        print("enter account holder number :")
        acno = Int(readLine()!)!
        print("enter account holdar mobile number :")
        acmo = Int(readLine()!)!
        print("enter account holdar email :")
        acmail = readLine()!
    }
}
