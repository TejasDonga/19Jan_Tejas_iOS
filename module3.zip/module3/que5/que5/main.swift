//
//  main.swift
//  que5
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation


let num = [4, 5, 2, 1, 6  ]
let sorted  = num.sorted(by:{ ( num1: Int, num2: Int) -> Bool in
    return num1 < num2
})
print(sorted)
