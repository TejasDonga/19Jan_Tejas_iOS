//
//  main.swift
//  que6
//
//  Created by mac on 07/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

func sum (num1: Double,num2: Double) -> Double {
     return num1+num2
}
func sub (num1: Double,_ num2: Double) -> Double{
    return num1-num2
}
func mul (num1: Double,_ num2: Double)-> Double{
    return num1*num2
}
func div (num1: Double, _ num2: Double)-> Double{
    return num1/num2
}

var t = sum(num1: 12, num2: 44)
print("sum:",(t))

var r = sub(num1: 12, 23)
print("sub:",(r))

var d = mul(num1: 45, 12)
print("mul:",(d))

var s = div(num1: 12, 6)
print("div:",(s))


