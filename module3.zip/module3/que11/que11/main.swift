//
//  main.swift
//  que11
//
//  Created by mac on 16/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

protocol data {
    func gatdata(id:Int,name: String)
    func gatcontect(number:Int)
}

class datail:data {
    func gatdata(id: Int, name: String) {
        print("my id:",id)
        print("my name:",name)
    }
    
    func gatcontect(number: Int) {
        print("my number:",number)
    }
}
var st = datail()
st.gatdata(id: 1, name: "tejas")
st.gatcontect(number: 8980316382)
