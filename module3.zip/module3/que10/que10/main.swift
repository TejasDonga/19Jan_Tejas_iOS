//
//  main.swift
//  que10
//
//  Created by mac on 13/03/23.
//  Copyright © 2023 mac. All rights reserved.
//

import Foundation

struct bankdata {
    var acnm : String
    var acmo : Double
    var acbal : Double
    var acno : Double
    var acem : String
}

var ac1 = bankdata(acnm: "tejas", acmo: 35832633653, acbal: 521464, acno: 3543546484510, acem: "Tops@gmail.com")
var ac2 = bankdata(acnm: "krushal", acmo: 9925513025, acbal: 54641, acno: 5464832544511, acem: "adfsdsdgsgb")
var ac3 = bankdata(acnm: "Vasu", acmo: 854550000865, acbal: 5454642, acno: 546484512, acem: "banTops@gmail.com")
var ac4 = bankdata(acnm: "jatin", acmo: 4684351841, acbal: 54643, acno: 546484513, acem: "Tops@gmail.com")
var ac5 = bankdata(acnm: "Het", acmo: 4684351842, acbal: 54644, acno: 546484514, acem: "Tops@gmail.com")
var ac6 = bankdata(acnm: "keyur", acmo: 4684351843, acbal: 54645, acno: 546484515, acem: "Tops@gmail.com")
var ac7 = bankdata(acnm: "Atul", acmo: 4684351844, acbal: 54646, acno: 546484516, acem: "Tops@gmail.com")
var ac8 = bankdata(acnm: "radhey", acmo: 4684351845, acbal: 54647, acno: 546484517, acem: "Tops@gmail.com")
var ac9 = bankdata(acnm: "Nirav", acmo: 4684351846, acbal: 54648, acno: 546484518, acem: "Tops@gmail.com")
var ac10 = bankdata(acnm: "sanket", acmo: 4684351847, acbal: 54649, acno: 546484519, acem: "Tops@gmail.com")

print(ac1)
print(ac2)
print(ac3)
print(ac4)
print(ac5)
print(ac6)
print(ac7)
print(ac8)
print(ac9)
print(ac10)

